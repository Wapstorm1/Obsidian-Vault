1. Reproduce the issue
2. Use DevTools to check what is loading slow
3. Check backend perfomance like API response time, server logs or DB quiries (to see how long does it take to log a data)
4. **Test Load and Stress**: Simulate high traffic with tools like JMeter to pinpoint bottlenecks.
5. 