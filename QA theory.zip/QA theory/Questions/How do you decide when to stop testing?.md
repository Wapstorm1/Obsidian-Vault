1. Exit criteria must be met
   All planned test cases were executed successfully
   Critical or major bug were resolved and tested
2. Deadlines and budjet
   Are to key moments that can be crucial in test ending
3. Requirement coverage
   All requirements were covered by test cases and tested
4. User approve