**Scenario: Testing a bank’s ATM functionality.**
**Matrix Goal**: Map **user actions** to the **expected system responses**.
![[Pasted image 20250107171843.png]]

**Requirement Traceability Matrix (RTM)**

**Scenario: Testing an e-commerce platform.**
**Matrix Goal**: Trace requirements to test cases.
![[Pasted image 20250107171918.png]]
