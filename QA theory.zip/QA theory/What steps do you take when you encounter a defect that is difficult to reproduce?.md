Understand the conditions under which defect appears. Detailed reproduction step by step. Try to look at the logs. 
