1. **Understanding the requirements:**
   Review all user stories, BRDs, project requirements to understand what needs to be tested?
2. Identify the scope Features:
   Focus on critical functionalities, main workflow, integrations. 
3. Define out-of scope areas:
   Exclude all functionalities that are not critical or are not part of this release/sprint
4. Test types
   Functional, non-functional, exploratory, ad-foc etc.
5. Assess Risks
   Focus your attention on a high risk areas